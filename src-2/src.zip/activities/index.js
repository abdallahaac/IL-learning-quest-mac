import Activity01 from "./Activity01.jsx";
import Activity02 from "./Activity02.jsx";
import Activity03 from "./Activity03.jsx";
import Activity04 from "./Activity04.jsx";
import Activity05 from "./Activity05.jsx";
import Activity06 from "./Activity06.jsx";
import Activity07 from "./Activity07.jsx";
import Activity08 from "./Activity08.jsx";
import Activity09 from "./Activity09.jsx";
import Activity10 from "./Activity10.jsx";

export const ACTIVITY_PAGES = [
  Activity01,
  Activity02,
  Activity03,
  Activity04,
  Activity05,
  Activity06,
  Activity07,
  Activity08,
  Activity09,
  Activity10
];
