// A simple re-export to keep Activity pages within the pages directory.
// This allows AppShell to import ActivityPage consistently with other page components.
export { default } from "../components/Activity.jsx";